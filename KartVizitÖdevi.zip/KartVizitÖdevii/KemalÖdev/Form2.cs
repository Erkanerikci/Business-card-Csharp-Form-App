﻿using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

namespace Kartvizit
{
    public partial class Form2 : Form
    {
        SqlConnection baglanti;
        SqlCommand komut;
        SqlDataAdapter da;

        public Form2()
        {
            InitializeComponent();
        }

        void OgrenciGetir()
        {
            baglanti = new SqlConnection(@"Data Source=DARK;Initial Catalog=Kartvizit;Integrated Security=True");
            baglanti.Open();
            da = new SqlDataAdapter("SELECT * FROM ogrenci", baglanti);
            DataTable tablo = new DataTable();
            da.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            OgrenciGetir();
            dataGridView1.Columns["resim"].DefaultCellStyle.NullValue = null;
            dataGridView1.Columns["resim"].DefaultCellStyle.Padding = new Padding(-31);
            ((DataGridViewImageColumn)dataGridView1.Columns["resim"]).ImageLayout = DataGridViewImageCellLayout.Zoom;
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtno.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtad.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtfak.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtbolum.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            byte[] imageData = (byte[])dataGridView1.CurrentRow.Cells[4].Value;
            pictureBox1.Image = ByteArrayToImage(imageData);
        }

        private void btnfoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog dosya = new OpenFileDialog();
            dosya.Filter = "Resim Dosyası |*.jpg;*.nef;*.png |  Tüm Dosyalar |*.*";
            dosya.ShowDialog();
            string dosyayolu = dosya.FileName;
            btnekle.Text = dosyayolu;
            pictureBox1.ImageLocation = dosyayolu;
        }

        private void btnekle_Click(object sender, EventArgs e)
        {
            byte[] imageData = ImageToByteArray(pictureBox1.Image);

            string sorgu = "INSERT INTO ogrenci(ogrencino, adsoyad, fakulte, bolum, Resim) VALUES(@ogrencino, @adsoyad, @fakulte, @bolum, @Resim)";
            komut = new SqlCommand(sorgu, baglanti);
            komut.Parameters.AddWithValue("@ogrencino", txtno.Text);
            komut.Parameters.AddWithValue("@adsoyad", txtad.Text);
            komut.Parameters.AddWithValue("@fakulte", txtfak.Text);
            komut.Parameters.AddWithValue("@bolum", txtbolum.Text);
            komut.Parameters.Add("@Resim", SqlDbType.VarBinary, -1).Value = imageData;
            baglanti.Open();
            komut.ExecuteNonQuery();
            baglanti.Close();
            OgrenciGetir();
        }

        private void btnsil_Click(object sender, EventArgs e)
        {
            string sorgu = "DELETE FROM ogrenci WHERE ogrencino=@ogrencino";
            komut = new SqlCommand(sorgu, baglanti);
            komut.Parameters.AddWithValue("@ogrencino", Convert.ToInt32(txtno.Text));
            baglanti.Open();
            komut.ExecuteNonQuery();
            baglanti.Close();
            OgrenciGetir();
        }

        private bool AreImagesEqual(Image image1, Image image2)
        {
            if (image1.Width != image2.Width || image1.Height != image2.Height)
            {
                return false;
            }

            using (MemoryStream ms1 = new MemoryStream())
            using (MemoryStream ms2 = new MemoryStream())
            {
                image1.Save(ms1, ImageFormat.Png);
                image2.Save(ms2, ImageFormat.Png);

                byte[] image1Bytes = ms1.ToArray();
                byte[] image2Bytes = ms2.ToArray();

                return StructuralComparisons.StructuralEqualityComparer.Equals(image1Bytes, image2Bytes);
            }
        }

        private void btnguncelle_Click(object sender, EventArgs e)
        {
            string ogrenciNo = txtno.Text;
            string yeniAdSoyad = txtad.Text;
            string yeniFakulte = txtfak.Text;
            string yeniProgram = txtbolum.Text;

            byte[] currentImageData = GetImageFromDatabase(Convert.ToInt32(ogrenciNo));
            Image eskiResim = ByteArrayToImage(currentImageData);

            Image yeniResim = pictureBox1.Image;

            byte[] yeniResimBytes;
            if (!AreImagesEqual(yeniResim, eskiResim))
            {
                yeniResimBytes = ImageToByteArray(yeniResim);
            }
            else
            {
                yeniResimBytes = currentImageData;
            }

            string connectionString = "Data Source=DARK;Initial Catalog=Kartvizit;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();

                string kontrolQuery = "SELECT COUNT(*) FROM ogrenci WHERE ogrencino = @OgrenciNo";

                using (SqlCommand kontrolCommand = new SqlCommand(kontrolQuery, connection))
                {
                    kontrolCommand.Parameters.AddWithValue("@OgrenciNo", ogrenciNo);

                    int ogrenciSayisi = (int)kontrolCommand.ExecuteScalar();

                    if (ogrenciSayisi > 0)
                    {
                        string guncellemeQuery = "UPDATE ogrenci SET adsoyad = @YeniAdSoyad, fakulte = @YeniFakulte, bolum = @YeniProgram, Resim = @YeniResim WHERE ogrencino = @OgrenciNo";

                        using (SqlCommand guncellemeCommand = new SqlCommand(guncellemeQuery, connection))
                        {
                            guncellemeCommand.Parameters.AddWithValue("@OgrenciNo", ogrenciNo);
                            guncellemeCommand.Parameters.AddWithValue("@YeniAdSoyad", yeniAdSoyad);
                            guncellemeCommand.Parameters.AddWithValue("@YeniFakulte", yeniFakulte);
                            guncellemeCommand.Parameters.AddWithValue("@YeniProgram", yeniProgram);
                            guncellemeCommand.Parameters.Add("@YeniResim", SqlDbType.VarBinary, -1).Value = yeniResimBytes;

                            guncellemeCommand.ExecuteNonQuery();

                            MessageBox.Show("Öğrenci bilgileri ve resmi başarıyla güncellendi.");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Öğrenci bulunamadı. Lütfen geçerli bir öğrenci numarası girin.");
                    }
                }
            }

            OgrenciGetir();
        }

        private byte[] GetImageFromDatabase(int ogrenciNo)
        {
            byte[] imageData = null;
            string connectionString = "Data Source=DARK;Initial Catalog=Kartvizit;Integrated Security=True";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                string query = "SELECT Resim FROM ogrenci WHERE ogrencino = @OgrenciNo";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@OgrenciNo", ogrenciNo);
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            if (!reader.IsDBNull(0))
                            {
                                imageData = (byte[])reader[0];
                            }
                        }
                    }
                }
            }

            return imageData;
        }

        private byte[] ImageToByteArray(Image image)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                image.Save(ms, ImageFormat.Png);
                return ms.ToArray();
            }
        }

        private Image ByteArrayToImage(byte[] byteArray)
        {
            using (MemoryStream ms = new MemoryStream(byteArray))
            {
                Image image = Image.FromStream(ms);
                return new Bitmap(image);
            }
        }

        private void btnyazdir_Click(object sender, EventArgs e)
        {
            string OgrenciAdi = txtad.Text;
            string OgrenciNo = txtno.Text;
            string OgrenciFakulte = txtfak.Text;
            string OgrenciBolum = txtbolum.Text;

            Form3 form3 = new Form3(OgrenciAdi, OgrenciNo, OgrenciFakulte, OgrenciBolum);
            form3.Show();
            form3.SetPictureBox2Image(pictureBox1.Image);
        }
    }
}
