﻿namespace KemalÖdev
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            txtno = new TextBox();
            txtad = new TextBox();
            txtokul = new TextBox();
            txtbolum = new TextBox();
            btnPdf = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(47, 311);
            label1.Name = "label1";
            label1.Size = new Size(142, 15);
            label1.TabIndex = 0;
            label1.Text = "Öğrenci No /Student No: ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(47, 341);
            label2.Name = "label2";
            label2.Size = new Size(159, 15);
            label2.TabIndex = 0;
            label2.Text = "Adı Soyadı / Name Surname:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(47, 372);
            label3.Name = "label3";
            label3.Size = new Size(207, 15);
            label3.TabIndex = 0;
            label3.Text = "Fakülte-Yüksekokul / Faculty-Collage:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(47, 402);
            label4.Name = "label4";
            label4.Size = new Size(130, 15);
            label4.TabIndex = 0;
            label4.Text = "Porgram / Department:";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(33, 26);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(243, 89);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(644, 26);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(106, 89);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // txtno
            // 
            txtno.BackColor = SystemColors.Menu;
            txtno.Location = new Point(255, 303);
            txtno.Name = "txtno";
            txtno.Size = new Size(156, 23);
            txtno.TabIndex = 3;
            // 
            // txtad
            // 
            txtad.BackColor = SystemColors.Control;
            txtad.Location = new Point(255, 333);
            txtad.Name = "txtad";
            txtad.Size = new Size(156, 23);
            txtad.TabIndex = 3;
            // 
            // txtokul
            // 
            txtokul.BackColor = SystemColors.Control;
            txtokul.Location = new Point(255, 364);
            txtokul.Name = "txtokul";
            txtokul.Size = new Size(156, 23);
            txtokul.TabIndex = 3;
            // 
            // txtbolum
            // 
            txtbolum.BackColor = SystemColors.Control;
            txtbolum.Location = new Point(255, 394);
            txtbolum.Name = "txtbolum";
            txtbolum.Size = new Size(156, 23);
            txtbolum.TabIndex = 3;
            // 
            // btnPdf
            // 
            btnPdf.Location = new Point(644, 323);
            btnPdf.Name = "btnPdf";
            btnPdf.Size = new Size(98, 64);
            btnPdf.TabIndex = 4;
            btnPdf.Text = "PDF Haline Getir";
            btnPdf.UseVisualStyleBackColor = true;
            btnPdf.Click += btnPdf_Click;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnPdf);
            Controls.Add(txtbolum);
            Controls.Add(txtokul);
            Controls.Add(txtad);
            Controls.Add(txtno);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form3";
            Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private TextBox txtno;
        private TextBox txtad;
        private TextBox txtokul;
        private TextBox txtbolum;
        private Button btnPdf;
    }
}