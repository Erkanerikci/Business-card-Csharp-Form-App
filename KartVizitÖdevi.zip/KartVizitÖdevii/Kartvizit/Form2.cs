﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

namespace Kartvizit
{
    public partial class Form2 : Form
    {
        SqlConnection baglanti;
        SqlCommand komut;
        SqlDataAdapter da;

        public Form2()
        {
            InitializeComponent();
        }

        void OgrenciGetir()
        {
            baglanti = new SqlConnection(@"Data Source=DARK;Initial Catalog=Kartvizit;Integrated Security=True");
            baglanti.Open();
            da = new SqlDataAdapter("SELECT * FROM ogrenci", baglanti);
            DataTable tablo = new DataTable();
            da.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            OgrenciGetir();
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtno.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtad.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtfak.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtbolum.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();
            byte[] imageData = (byte[])dataGridView1.CurrentRow.Cells[4].Value;
            pictureBox1.Image = ByteArrayToImage(imageData);
        }

        private void btnfoto_Click(object sender, EventArgs e)
        {
            OpenFileDialog dosya = new OpenFileDialog();
            dosya.Filter = "Resim Dosyası |*.jpg;*.nef;*.png |  Tüm Dosyalar |*.*";
            dosya.ShowDialog();
            string dosyayolu = dosya.FileName;
            btnekle.Text = dosyayolu;
            pictureBox1.ImageLocation = dosyayolu;
        }

        private void btnekle_Click(object sender, EventArgs e)
        {
            byte[] imageData = ImageToByteArray(pictureBox1.Image);

            string sorgu = "INSERT INTO ogrenci(ogrencino, adsoyad, fakulte, bolum, Resim) VALUES(@ogrencino, @adsoyad, @fakulte, @bolum, @Resim)";
            komut = new SqlCommand(sorgu, baglanti);
            komut.Parameters.AddWithValue("@ogrencino", txtno.Text);
            komut.Parameters.AddWithValue("@adsoyad", txtad.Text);
            komut.Parameters.AddWithValue("@fakulte", txtfak.Text);
            komut.Parameters.AddWithValue("@bolum", txtbolum.Text);
            komut.Parameters.Add("@Resim", SqlDbType.VarBinary, -1).Value = imageData; // Resim parametresini ekler
            baglanti.Open();
            komut.ExecuteNonQuery();
            baglanti.Close();
            OgrenciGetir();
        }

        private void btnsil_Click(object sender, EventArgs e)
        {
            string sorgu = "DELETE FROM ogrenci WHERE ogrencino=@ogrencino";
            komut = new SqlCommand(sorgu, baglanti);
            komut.Parameters.AddWithValue("@ogrencino", Convert.ToInt32(txtno.Text));
            baglanti.Open();
            komut.ExecuteNonQuery();
            baglanti.Close();
            OgrenciGetir();
        }

        private void btnguncelle_Click(object sender, EventArgs e)
        {
            byte[] imageData = ImageToByteArray(pictureBox1.Image);

            string sorgu = "UPDATE ogrenci SET adsoyad=@adsoyad, fakulte=@fakulte, bolum=@bolum, Resim=@Resim WHERE ogrencino=@ogrencino";
            komut = new SqlCommand(sorgu, baglanti);
            komut.Parameters.AddWithValue("@ogrencino", Convert.ToInt32(txtno.Text));
            komut.Parameters.AddWithValue("@adsoyad", txtad.Text);
            komut.Parameters.AddWithValue("@fakulte", txtfak.Text);
            komut.Parameters.AddWithValue("@bolum", txtbolum.Text);
            komut.Parameters.Add("@Resim", SqlDbType.VarBinary, -1).Value = imageData; // Resim parametresini ekler

            baglanti.Open();
            komut.ExecuteNonQuery();
            baglanti.Close();
            OgrenciGetir();
        }

        // Resmi byte dizisine dönüştüren fonksiyon
        private byte[] ImageToByteArray(Image image)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                image.Save(ms, ImageFormat.Jpeg);
                return ms.ToArray();
            }
        }

        // Byte dizisini resme dönüştüren fonksiyon
        private Image ByteArrayToImage(byte[] byteArray)
        {
            using (MemoryStream ms = new MemoryStream(byteArray))
            {
                Image image = Image.FromStream(ms);
                return image;
            }
        }

        private void btnyazdir_Click(object sender, EventArgs e)
        {
            string OgrenciAdi = txtad.Text;
            string OgrenciNo = txtno.Text;
            string OgrenciFakulte = txtfak.Text;
            string OgrenciBolum = txtbolum.Text;

            Form3 form3 = new Form3(OgrenciAdi, OgrenciNo, OgrenciFakulte, OgrenciBolum);
            form3.Show();
            form3.SetPictureBox2Image(pictureBox1.Image); // İlk PictureBox'daki resmi Form3'teki ilgili PictureBox'a aktar;
        }
    }
}