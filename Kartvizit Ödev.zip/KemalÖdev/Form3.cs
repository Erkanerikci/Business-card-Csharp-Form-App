﻿using System;
using System.Collections.Generic;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Document = iTextSharp.text.Document;
using Rectangle = System.Drawing.Rectangle;

namespace KemalÖdev
{
    public partial class Form3 : Form
    {



        public Form3(string OgrenciNo, string OgrenciAdi, string OgrenciFakulte, string OgrenciBolum)
        {
            InitializeComponent();

            txtno.Text = OgrenciNo;
            txtad.Text = OgrenciAdi;
            txtokul.Text = OgrenciFakulte;
            txtbolum.Text = OgrenciBolum;
        }

        private void btnPdf_Click(object sender, EventArgs e)
        {
            btnPdf.Visible = false;
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "PDF Dosyası|*.pdf";
            saveFileDialog.Title = "PDF Olarak Kaydet";
            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                string pdfFilePath = saveFileDialog.FileName;

                // PDF belgesi oluştur
                Document pdfDoc = new iTextSharp.text.Document(PageSize.A0);
                PdfWriter.GetInstance(pdfDoc, new FileStream(pdfFilePath, FileMode.Create));

                pdfDoc.Open(); 
               


                using (MemoryStream ms = new MemoryStream())
                {
                    
                    Bitmap bitmap = new Bitmap(this.Width, this.Height);
                    this.DrawToBitmap(bitmap, new Rectangle(0, 0, this.Width, this.Height));
                    bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Png);
                    iTextSharp.text.Image img = iTextSharp.text.Image.GetInstance(ms.GetBuffer());

                 
                    pdfDoc.Add(img);
                    
                    
                }

                pdfDoc.Close();
                btnPdf.Visible = true;
                
                MessageBox.Show("Form PDF olarak dışa aktarıldı.", "Bilgi", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
