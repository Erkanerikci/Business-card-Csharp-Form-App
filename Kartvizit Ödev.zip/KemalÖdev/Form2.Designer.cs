﻿namespace KemalÖdev
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            txtno = new TextBox();
            txtad = new TextBox();
            txtfak = new TextBox();
            txtbolum = new TextBox();
            dataGridView1 = new DataGridView();
            btnekle = new Button();
            btnsil = new Button();
            btnguncelle = new Button();
            btnyazdir = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(52, 31);
            label1.Name = "label1";
            label1.Size = new Size(103, 15);
            label1.TabIndex = 0;
            label1.Text = "Öğrenci Numarası";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(52, 62);
            label2.Name = "label2";
            label2.Size = new Size(57, 15);
            label2.TabIndex = 0;
            label2.Text = "Ad Soyad";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(52, 95);
            label3.Name = "label3";
            label3.Size = new Size(45, 15);
            label3.TabIndex = 0;
            label3.Text = "Fakülte";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(52, 124);
            label4.Name = "label4";
            label4.Size = new Size(42, 15);
            label4.TabIndex = 0;
            label4.Text = "Bölüm";
            // 
            // txtno
            // 
            txtno.Location = new Point(171, 28);
            txtno.Name = "txtno";
            txtno.Size = new Size(152, 23);
            txtno.TabIndex = 1;
            // 
            // txtad
            // 
            txtad.Location = new Point(171, 59);
            txtad.Name = "txtad";
            txtad.Size = new Size(152, 23);
            txtad.TabIndex = 1;
            // 
            // txtfak
            // 
            txtfak.Location = new Point(171, 92);
            txtfak.Name = "txtfak";
            txtfak.Size = new Size(152, 23);
            txtfak.TabIndex = 1;
            // 
            // txtbolum
            // 
            txtbolum.Location = new Point(171, 121);
            txtbolum.Name = "txtbolum";
            txtbolum.Size = new Size(152, 23);
            txtbolum.TabIndex = 1;
            // 
            // dataGridView1
            // 
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(52, 211);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.Size = new Size(613, 195);
            dataGridView1.TabIndex = 2;
            dataGridView1.CellEnter += dataGridView1_CellEnter;
            // 
            // btnekle
            // 
            btnekle.Location = new Point(460, 21);
            btnekle.Name = "btnekle";
            btnekle.Size = new Size(93, 34);
            btnekle.TabIndex = 3;
            btnekle.Text = "Ekle";
            btnekle.UseVisualStyleBackColor = true;
            btnekle.Click += btnekle_Click;
            // 
            // btnsil
            // 
            btnsil.Location = new Point(460, 62);
            btnsil.Name = "btnsil";
            btnsil.Size = new Size(93, 34);
            btnsil.TabIndex = 3;
            btnsil.Text = "Çıkar";
            btnsil.UseVisualStyleBackColor = true;
            btnsil.Click += btnsil_Click;
            // 
            // btnguncelle
            // 
            btnguncelle.Location = new Point(460, 105);
            btnguncelle.Name = "btnguncelle";
            btnguncelle.Size = new Size(93, 34);
            btnguncelle.TabIndex = 3;
            btnguncelle.Text = "Güncelle";
            btnguncelle.UseVisualStyleBackColor = true;
            btnguncelle.Click += btnguncelle_Click;
            // 
            // btnyazdir
            // 
            btnyazdir.Location = new Point(596, 54);
            btnyazdir.Name = "btnyazdir";
            btnyazdir.Size = new Size(91, 50);
            btnyazdir.TabIndex = 4;
            btnyazdir.Text = "Yazdır";
            btnyazdir.UseVisualStyleBackColor = true;
            btnyazdir.Click += btnyazdir_Click;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnyazdir);
            Controls.Add(btnguncelle);
            Controls.Add(btnsil);
            Controls.Add(btnekle);
            Controls.Add(dataGridView1);
            Controls.Add(txtbolum);
            Controls.Add(txtfak);
            Controls.Add(txtad);
            Controls.Add(txtno);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private TextBox txtno;
        private TextBox txtad;
        private TextBox txtfak;
        private TextBox txtbolum;
        private DataGridView dataGridView1;
        private Button btnekle;
        private Button btnsil;
        private Button btnguncelle;
        private Button btnyazdir;
    }
}