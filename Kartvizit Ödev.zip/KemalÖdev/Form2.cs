﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace KemalÖdev
{
    public partial class Form2 : Form
    {
        SqlConnection baglanti;
        SqlCommand komut;
        SqlDataAdapter da;
        public Form2()
        {
            InitializeComponent();
        }

        void OgrenciGetir()
        {
            baglanti = new SqlConnection(@"Data Source=DARK;Initial Catalog=Kartvizit;Integrated Security=True");
            baglanti.Open();
            da = new SqlDataAdapter("SELECT * FROM ogrenci", baglanti);
            DataTable tablo = new DataTable();
            da.Fill(tablo);
            dataGridView1.DataSource = tablo;
            baglanti.Close();

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            OgrenciGetir();
        }

        private void dataGridView1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
            txtno.Text = dataGridView1.CurrentRow.Cells[0].Value.ToString();
            txtad.Text = dataGridView1.CurrentRow.Cells[1].Value.ToString();
            txtfak.Text = dataGridView1.CurrentRow.Cells[2].Value.ToString();
            txtbolum.Text = dataGridView1.CurrentRow.Cells[3].Value.ToString();

        }

        private void btnekle_Click(object sender, EventArgs e)
        {

            string sorgu = "INSERT INTO ogrenci(ogrencino,adsoyad,fakulte,bolum) VALUES(@ogrencino,@adsoyad,@fakulte,@bolum)";
            komut = new SqlCommand(sorgu, baglanti);
            komut.Parameters.AddWithValue("@ogrencino", txtno.Text);
            komut.Parameters.AddWithValue("@adsoyad", txtad.Text);
            komut.Parameters.AddWithValue("@fakulte", txtfak.Text);
            komut.Parameters.AddWithValue("@bolum", txtbolum.Text);
            baglanti.Open();
            komut.ExecuteNonQuery();
            baglanti.Close();
            OgrenciGetir();


        }

        private void btnsil_Click(object sender, EventArgs e)
        {
            string sorgu = "DELETE FROM ogrenci WHERE ogrencino=@ogrencino";
            komut = new SqlCommand(sorgu, baglanti);
            komut.Parameters.AddWithValue("@ogrencino", Convert.ToInt32(txtno.Text));
            baglanti.Open();
            komut.ExecuteNonQuery();
            baglanti.Close();
            OgrenciGetir();
        }

        private void btnguncelle_Click(object sender, EventArgs e)
        {
            string sorgu = "UPDATE ogrenci SET adsoyad=@adsoyad,fakulte=@fakulte,bolum=@bolum WHERE ogrencino=@ogrencino";
            komut = new SqlCommand(sorgu, baglanti);
            komut.Parameters.AddWithValue("@ogrencino", Convert.ToInt32(txtno.Text));
            komut.Parameters.AddWithValue("@adsoyad", (txtad.Text));
            komut.Parameters.AddWithValue("@fakulte", (txtfak.Text));
            komut.Parameters.AddWithValue("@bolum", (txtbolum.Text));
            baglanti.Open();
            komut.ExecuteNonQuery();
            baglanti.Close();
            OgrenciGetir();
        }

        private void btnyazdir_Click(object sender, EventArgs e)
        {
           
            string OgrenciAdi = txtad.Text;
            string OgrenciNo = txtno.Text;
            string OgrenciFakulte = txtfak.Text;
            string OgrenciBolum = txtbolum.Text;
            Form3 form3 = new Form3(OgrenciAdi, OgrenciNo, OgrenciFakulte, OgrenciBolum);
            form3.Show();



        }
    }
}
